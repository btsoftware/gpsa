﻿=== WangGuard ===
Contributors: j.conti,maxidirienzo,InTouchSystem
Author URI: http://wangguard.com
Tags: wangguard, wgg, sploggers, splog, anti-splog, user spam, anti spam users, anti-spam, spam blog, spam blogs, wordpress, buddypress, wpmu, wordpress mu, wordpress multisite, standard WordPress, registration, security, security questions, plugin, sign up, signup, spam, wp-login.php, wp-signup.php, wp-register.php, register, registration, protect, protect registration, block agents, block ip, blog secure, bots, secure blog, secure wordpress, secure wp, website security, wp secure, wp security, block users, block user, block, block emails, block e-mails, block domains, block bots, block bot, bp, captcha, no captcha, recaptcha, unwanted users, block unwanted users, block splog, black hat, blackhat, bbpress, clean, clean database, clean splog, clean users, untrusted, untrusted users, ip, ip information, user admin, user management, advanced user management, ip info, appthemes, user registration spam, users registration spam, user registration spam prevention, users registration spam prevention, woocommerce
Requires at least: 3.0
Tested up to: 3.9
Stable tag: 1.6-RC1
License: GPLv2

The most advanced protection against sploggers and spam users registration, is fully WordPress,WordPress MU ,BuddyPress and bbPress 2.0 compatible


== Description ==

= Welcome to WangGuard, Welcome to the revolution =

= WangGuard Add-ons =

 * [WangGuard - MailPoet Connector](http://wordpress.org/plugins/wangguard-wysija-newsletter-connector/)
 * [WangGuard Blacklisted Words](http://wordpress.org/plugins/wangguard-blacklisted-words-add-on/)
 * [WangGuard Limited Registration Domain](http://wordpress.org/plugins/wangguard-limited-registration-domain-add-on/)
 * [WangGuard Registration Notice](http://wordpress.org/plugins/wangguard-registration-notice-add-on/)

And more to come!

[Please, read the WangGuard's philosophy](http://wangguard.org/2011/12/26/welcome-to-wangguard-welcome-to-the-revolution/)

WangGuard works by incorporating an antivirus philosophy.

[Follow us on Twitter](http://twitter.com/wangguard)

WangGuard Always will be free for personal use, this means that whenever you have less than 500 daily registrations or you make less than $200/month, you never have to pay anything for WangGuard.

Over 54.500.000+ Splogger/unwanted users blocked in just 2 years and half.

WangGuard already is blocking 99.90% of sploggers and unwanted users.

[What are users and Sploggers saying?](http://wordpress.org/extend/plugins/wangguard/other_notes/)

[Did you find a bug?](https://github.com/joseconti/WangGuard/issues)

[Do you want to translate WangGuard?](https://github.com/joseconti/WangGuard)

[Have you an Idea for WangGuard?](https://github.com/joseconti/WangGuard/issues)


= Advice =

 * If you are using W3 Total Cache and you have enabled HTML&XML Minify and you use BuddyPress or a custom registration page. Please, go to Performance -> Minify -> Advanced -> "Never minify the following pages:" and add you registration page. If you dont do this, you could have some issues.
 
 * WangGuard NOT protect your site from comment spam, WangGuard protect your registration page from sploggers, unwanted users and untrusted users and WangGuard clean your database from them. For comment spam, you have another great plugin, [Akismet](http://wordpress.org/extend/plugins/akismet/).

 * WangGuard protect the standard WordPress, WordPress Multisite, BuddyPress and bbPress 2.0 registration forms. If you use custom registration page, maybe WangGuard will not work. If you use a plugin or custom registration page, once you've installed WangGuard, test if it works. if it doesn't work, talk with the plugin developer or with your developer to make it compatible or use the standard WordPress, WordPress Multisite, BuddyPress or bbPress 2.0 signup form.



WangGuard is fully compatible with Standard WordPress (non-multisite), WordPress MU, WordPress Multisite, BuddyPress (multisite and non-multisite), bbPress 2.0, and plugins like WooCommerce.

If you have signup enabled on your Standard WordPress, WordPress MU, WordPress Multisite, BuddyPress, bbPress 2.0, or 'my profile' in WooCommerce this is the plugin you were waiting for. There is nothing like it, is a next generation plugin associated a web service and a new concept of active protection from Sploggers, spam users, unwanted users and Black Hat SEO. This is just the beginning.

WangGuard not only protect your site from sploggers, spam users or unwanted users, WangGuard cleans your database from them. No plugin or service does this, only with WangGuard you will get this feature.


Now Free to everyone for a limited time!. Who make more than $200/month, need more than 500 API Queries/month or a company they not have to pay anything until at least January 2013. We will not charge anything until we develop everything that we want to develop and be the best service by far.


= Introduction to WangGuard: =


[wpvideo RGdn6YSg]



It is very important to use WangGuard at least for a week, reporting your site's unwanted users as sploggers from the Users panel.

WangGuard will learn at that time to protect your site from sploggers in a much more effective way.

WangGuard protects each web site in a personalized way using information provided by Administrators who report sploggers world-wide, that's why it's very important that you report your sploggers to WangGuard.

The longer you use WangGuard, the more effective it will become.

Upon user registration, WangGuard will check against a centralized database if the user is a Splogger or spam-user. If WangGuard determines that the user is a Splogger, WangGuard won't allow the registration on your site.

No need to put any kind of filter in the user registration page (eg captcha). This is the greatness of WangGuard, not hinder users who wish to register on your site with Captchas and other things that just makes the registration being more difficult and in many cases do not stop Sploggers. But in case you want to put something WangGuard gives you the ability to add one or more security questions from the plugin's administration page, which will be randomly displayed on the registration page.


= Why use WangGuard? =


 * WangGuard cleans your database from sploggers, spam users and unwanted users.
 * Is very dangerous to have sploggers, spam users or unwanted users, they could hack the site.
 * The sploggers, spam users  or unwanted users uses your server resources for their benefit. They can overload your site to their benefit hurting you and your users.
 * They hurt your position in search engines like Google.
 * Search engines such as Google can block your site because you are advertising illegal, prohibited or dangerous products or content.
 * Sploggers, spam users and unwanted users, bothers the rest of your users, this may cause them to sign off your site.
 * Do not bother your new users with complicated captchas that in most cases do not stop the sploggers, spam users or unwanted users.
 * WangGuard fixes all of these problems, and if you're a personal user, it does it for free.


= General Features =


 * Free API key for personal use
 * Free to everyone for a limited time!
 * Clean your installation of unwanted users and sploggers.
 * Centralized database of sploggers.
 * Block users emails by domains.
 * NEW Advanced User Management.
 * Configure from Admin panel
 * Valid HTML
 * I18n language translation support
 * Security questions
 * WangGuard find Sploggers, spam-users or unwanted users in your old ones registered users
 * WangGuard clean your database of Sploggers, spam-users or unwanted users 
 * Protect Standard WordPress registration page against Web Service from spam-user or unwanted users
 * Protect WordPress MU registration page against Web Service from Sploggers, spam-user or unwanted users
 * Protect WordPress Multisite (WP 3.x) registration page against Web Service from Sploggers, spam-user or unwanted users
 * Protect BuddyPress registration page against Web Service from Sploggers, spam-user or unwanted users
 * Protect bbPress 2.0 registration page against Web Service from Sploggers, spam-user or unwanted users
 * Anti-splog Web Service.
 * Disable WangGuard menu in WordPress & BuddyPress AdminBar
 * [AppThemes](http://www.appthemes.com/) compatible
 * WooCommerce integration
 

= WordPress Simple Features =

 * gmail.com and googlemail.com duplicated account verifications (activate on WangGuard Configuration)
 * Optional DNS verification of the email domain (right side of the @ in an email address) (activate on WangGuard Configuration)
 * Full Statistics
 * Added the ability to flag a user as "Not Splogger"
 * Wizard for detect and eliminate Sploggers
 * Mark as Splogger from post list
 
= WordPress Mu (WPMU) Features =

 * gmail.com and googlemail.com duplicated account verifications (activate on WangGuard Configuration)
 * Optional DNS verification of the email domain (right side of the @ in an email address) (activate on WangGuard Configuration)
 * Full Statistics
 * Added the ability to flag a user as "Not Splogger"
 * Wizard for detect and eliminate Sploggers
 * Mark as Splogger from post list
 * Protect all registration pages from All blogs (Activated sitewide)

= WordPress Multisite (WP3.x) Features =

 * New! Open Sun Sites from WangGuard Admin. You do not need more to visit the sub sites outsite Wordress Admin.
 * gmail.com and googlemail.com duplicated account verifications (activate on WangGuard Configuration)
 * Optional DNS verification of the email domain (right side of the @ in an email address) (activate on WangGuard Configuration)
 * Full Statistics
 * Added the ability to flag a user as "Not Splogger"
 * Wizard for detect and eliminate Sploggers
 * Mark as Splogger from post list
 * Add a "Report blog and author" on every blog
 * Moderation Queue for repored users and blogs
 * Protect all registration pages from All blogs (Activated for Network)
 
= BuddyPress 1.2.x and 1.5 (WordPress Simple and WordPress Multisite 3.x) Features =

 * gmail.com and googlemail.com duplicated account verifications (activate on WangGuard Configuration)
 * Optional DNS verification of the email domain (right side of the @ in an email address) (activate on WangGuard Configuration)
 * Full Statistics
 * Added the ability to flag a user as "Not Splogger"
 * Mark as Splogger from post list
 * Add "Report blog and author" on every blog
 * Moderation Queue for repored users and blogs
 * Add report user on every Activity
 * Add report user on every profile
 * Wizard for detect and eliminate Sploggers
 * Groups in WangGuard Users Screen
 
 = bbPress 2.0 Plugin =
 
 * gmail.com and googlemail.com duplicated account verifications (activate on WangGuard Configuration)
 * Optional DNS verification of the email domain (right side of the @ in an email address) (activate on WangGuard Configuration)
 * Full Statistics
 * Added the ability to flag a user as "Not Splogger"
 * Wizard for detect and eliminate Sploggers


= Requirements/Restrictions =


 * Works with Wordpress 3.8+, WPMU 3.8+, BuddyPress 1.0.3+, bbPress 2.0+ (Wordpress 3.9+ is highly recommended)
 * PHP 4.3 or above. (PHP 5+ is highly recommended)
  
 
 
= Configuration =


After the plugin is activated, you can configure it by selecting the "configuration" tab on the "WangGuard" page.


= Usage =


Obtain a new API KEY for your site from [WangGuard](http://www.wangguard.com/getapikey), then go to "configuration" on the "WangGuard" tab and paste the provided API KEY to activate WangGuard.

This step is not necessary, but if you want anyway, create the security questions that will appear randomly in the user registration page.

You can create or modify security questions and answers from the Admin panel.

Please go to WangGuard Wizard and use it.

Upon user registration, WangGuard will check against a centralized database if the user is a Splogger or spam-user. If WangGuard determines that the user is a Splogger, WangGuard won't allow the registration on your site.

You, as Admin, will be able to report existing SPloggers to WangGuard from the Admin panel.

If you flag a user as "spam", from either WordPress or BuddyPress, the user will be automatically reported as Splogger to WangGuard.

If you flag manually a user as Splogger, the user will be reported to WangGuard and also will be deleted from your WordPress, also, when multisite or network are enabled, the user's blogs will be flagged as "spam" blogs.



== Installation ==

1. Upload the "wangguard" folder to the "/wp-content/plugins/" directory, or download through the "Plugins" menu in WordPress

2. Activate the plugin through the "Plugins" menu in WordPress or Network activate for Multisite

3. Updates are automatic. Click on "Upgrade Automatically" if prompted from the admin menu. If you ever have to manually upgrade, simply deactivate, uninstall, and repeat the installation steps with the new version. 



== Screenshots ==

1. **WangGuard on WordPress** - WangGuard banning an unwanted user on WordPress registration page.
2. **WangGuard on WordPress Multisite** - WangGuard banning an unwanted user on WordPress Multisite registration page.
3. **WangGuard on BuddyPress** - WangGuard banning an unwanted user on BuddyPress registration page.
4. **WangGuard API Key** - WangGuard API key.
5. **WangGuard Configuration** - WangGuard configuration page.
6. **WangGuard Security Questions** - WangGuard Security Questions page.
7. **WangGuard server status** - WangGuard server status page.
8. **WangGuard Domain Block** - WangGuard Domain Block page.
9. **Advanced user Management** - Advanced User Management
10. **View subsites from WangGuard Users** - View subsites from WangGuard Users.
11. **Dashboard** - WangGuard Statistics on WordPress Dashboard.
12. **WangGuard Statistics** - Full WangGuard Statistics.
13. **Users** - WangGuard Bulk actions and WangGuard status.
14. **Report user** - WangGuard report user button on BuddyPress activities
15. **Report blog and author** - WangGuard Report blog and author link on the Admin bar (also featured on the BuddyPress bar)
16. **Moderation Queue** - WangGuard Moderation Queue
17. **Wizard** - WangGuard Wizard
18. **Report user on profile** - WangGuard Report user button on BuddyPress user profile
19. **Admin bar** - WangGuard admin bar group

== Frequently Asked Questions ==


= What do you mean with Personal use? =

This means that whenever you have less than 500 daily registrations, you make less than $200/month or you are not a company, you never have to pay anything for WangGuard.


= What do you mean with Limited Time? =

Who make more than $200/month, need more than 500 API Queries/month or is a company they not have to pay anything until at least June 2012, being able to extend until 2013. We will not charge anything until we develop everything that we want to develop and be the best service by far.


= If I am a personal user, Why I need an API Key? =

The API is that your site can talk to our server. If you have connected your site with other services like Facebook or Twitter services (also free) you're using API keys also, but they put other names to the API Key. We need to know who is connecting to our server for security reasons.



= Can I use WangGuard on non-multisites WordPress Installs (Standard WordPress)? =

Yes, absolutely. Only the WangGuard plugin and its associated web service will help to protect the registration page of your WordPress Standard, WordPress Multisite, or BuddyPress from sploggers and unwanted users.


= Is this plugin available in other languages? =

Yes. The following translations are included in the download zip file:

* Spanish (es_ES) - Translated by [WangGuard](http://wangguard.com/)
* Italian (it_IT) - Translate by Arturo
* German (de_DE) - Translated by Marco Jakobs
* Servian (sr_RS) - Tanslated by Borisa Djuraskovic
* Russian (ru_RU) - Tranlated by maxmadknight


= Can I provide a translation? =

Of course! It will be very gratefully received.

* Register on [Github](http://github.com)
* [Fork WangGuard](https://github.com/joseconti/WangGuard)
* Pull your translation

Please read [Translating WordPress](http://codex.wordpress.org/Translating_WordPress "Translating WordPress") first for background information on translating.
* There are some strings with a space or HTML tags, please make sure to respect them.



= Is WangGuard a free service? =

It is free for personal use. If you earn more than $200/month with your site or you are a company, you must pay a very small fee. Now WangGuard are Free to everyone for a limited time!. Use this time to perform all the tests you want and determine the effectiveness of WangGuard.


== Changelog ==

= 1.6 RC1 - 23 April 2014 =

- Added compatibility with WordPress 3.9.
- Added compatibility with BuddyPress 2.0.
- Added the ability of whitelist users
- Added some !important for fix some problems with some CSS at signup page.
- Added Contact page with us from WordPress admin.
- Added Add-ons page.
- Added Third party plugins page.
- Added ability of deactivate HoneyPot fieds.
- Added about WangGuard
- Added Credits page
- Added Development page (you can now follow WangGuard development)
- Added Help Us page
- Added Help page with First Steps and FAQ
- Added Welcome screen.
- Added User Info in WangGuard Users (Beta version).
- Added Unchecked Users
- Added German Localization by Marco Jakobs
- Added Servian Localization by Borisa Djuraskovic
- Added Russian Localization by maxmadknight
- Fixed a historical WangGuard CRON problem when BuddyPress is activated.
- Fixed compatibility with many custom signup page for Themes and plugins.


= 1.5.10 - 12 Aug 2013 =

- Fixed a problem with WangGuard users and BuddyPress without Groups component enabled.
- Added compatibility with the latest jQuery version in "Blocked Domains" WangGuard screen.
- Removed WangGuard statistics from Dashboard in WordPress 3.6. This is a temporal decision waiting for Wijmo update.

= 1.5.9.1 - 30 Jul 2013 =

- This update is critical for WooCommerce Users.
- Fix a bug in WooCommerce My Account page signup.
- Add support for other signup plugins combined with WooCommerce. 'My Account' signup has to be disabled from WooCommerce Settings.

= 1.5.9 - 30 Jul 2013 =

- Added ability to disable WangGuard Menu in WordPress & BuddyPress AdminBar. (Check WangGuard Settings).
- Added Groups created by users in WangGuard users screen (only BuddyPress). This will help to identify Splog users.
- Added more compatibility with BuddyPress (WangGuard now use more hooks for clean all user activity).
- Added compatibility WangGuard Cron <-> WooCommerce.

= 1.5.8 - 19 Jul 2013 =

- NEW Full Compatibility with CloudFlare. Now you will get the user's real IP instead of CloudFlare's IP. Thats means WangGuard will work 400% better on your website because WangGuard will know the real user's IP with this update. If you use CloudFlare, you need this update.

= 1.5.7.1 - 10 Jul 2013 =

- Fix a possible bug with WooCommerce.

= 1.5.7 - 9 Jul 2013 =

- NEW WooCommerce Compatibility.
- Minor tweaks to WangGuard cron to look for fix the cron problem in some installations
- Minor tweaks to registration Form


= 1.5.6 - 25 Jun 2013 =

- Added ability to open/visit BuddyPress users profiles in WangGuard Users Screen.
- Fixed some Notices.
- Added JS version for future updates.
- Added CSS version for future updates.
- Moved JS files and CSS files to their own directory

= 1.5.5 - 11 Jun 2013 =

- Added ability to open/visit subsites in WangGuard Users Screen (Only WordPress Multisite with or without BP).
- Added Unckeched users sreen in WangGuard Users.
- Increased Timeouts in WangGuard Wizard. Some servers had a problem with Timeouts.

= 1.5.4 - 21 Mar 2013 =

- Fix some compatibility problems with security questions on some new versions of AppThemes
- Added Compatibility with Ideas AppThemes
- Fix an overwritten menu problem to WangGuard by Gravity Form

= 1.5.3 - 21 Dec 2012 =
- Added the ability for other plugins to use WangGuard services to verify e-mail addresses. Check [the Wangguard Developers Page](http://www.wangguard.com/developers), we'll upload soon docs ands samples on how to use WangGuard services on your own plugins.
- Fixed a Javascript issue on the Dashboard and Stats page due to the new jQuery version used in Wordpress 3.5

= 1.5.2 - 4 Dec 2012 =
- Added compatibility for WordPress 3.5.
- Added the ability to remove the generator META tag (check WangGuard Settings)

= 1.5.1 - 9 Aug 2012 =
- Added the ability to avoid checking the IP address of the users when verifying them against WangGuard service, this option reduces WangGuard effectiveness, but if your new accounts come mostly from the same IP, in the case of colleges, universities or other large institutions, this would prevent WangGuard from flagging the IP address as suspicious.

= 1.5.0 - 11 Jul 2012 =
- Added WangGuard Cron Jobs to automatically verify your users against WangGuard, and flag or delete users that may not be identified as Sploggers at time they signup and catched later by WangGuard.
- Tweaked the stats barchar javascript files to include these only in the Dashboard and WangGuard Stats pages in order to avoid collision with other plugins / custom themes.

= 1.4.6.1 - 8 Jun 2012 =
- Added 3 missing JS files.

= 1.4.6 - 8 Jun 2012 =
- Added compatibility for WordPress 3.4.
- Fixed Report blog and author functionality for WP Multisite menu bar
- Avoid flagging as spam main the main blog (when using the WANGGUARD USERS SCREEN ONLY), it also flag as spam only the blogs for which the spam user is author or admin (previous version also flagged a blog as spam if the user was only a suscriber).

= 1.4.5 - 19 Apr 2012 =
- This is a recommended update
- Fix a bug in WangGuard wizard (Typo error). Thank to Paul Newsome of [www.nufcblog.org](http://www.nufcblog.org/) for report it.
- Now Security questions work with AppThemes Child Themes

= 1.4.4 - 13 Apr 2012 =
- Fix an issue with all AppThemes, now the WangGuard Security Question are well formatted.
- Minor tweaks to CSS

= 1.4.3 - 23 Mar 2012 =
- "Report blog" option is now shown on multisite installations.
- Solved a "Notice: Undefined index" error that may appear on the server's error log

= 1.4.2 - 20 Mar 2012 =
- Critical fix to workaround an IE compatibility issues to avoid legitimate users to be identified as Sploggers on registration screen.

= 1.4.1 - 13 Mar 2012 =
- jQuery library is not longer enqueued by the plugin except when BuddyPress is installed and "Show the report user button" is selected.
- BuddyPress options on WangGuard Settings page are no longer displayed when BuddyPress is not installed.

= 1.4 - 6 Mar 2012 =
- Added Advanced User Management.
- Fix minor issue where WangGuard CSS load on frontend.
- Revamped wizard. Now ask you for the advanced User Management.

= 1.3.2 - 11 Feb 2012 =
- CRITICAL UPDATE, fixes to the code due to a bug on the dbDelta() WordPress function, only affects to WordPress installations which uses capital letters in the database prefix.

= 1.3.1 - 10 Feb 2012 =
- Minor tweaks to improve Splogger identification and reporting accurancy

= 1.3 - 30 Jan 2012 =
- NEW Added the ability to block users which e-mail addresses belongs to well known domains, the domain's list is maintained by WangGuard. Go to WangGuard Configuration -> Blocked domains to select which domains you'd like to block.

= 1.2.6 - 23 Jan 2012 =
- Fix minor HTML/CSS issue on BuddyPress registration screen.

= 1.2.5 - 18 Jan 2012 =
- Fix minor HTML issue.
- Fix an issue where some users could give false positives.

= 1.2.4 - 12 Jan 2012 =
- Fix minor compatibility issue with BuddyPress 1.5.2 and 1.5.3 on register page.
- When running on jQuery 1.7.1 (WordPress 3.3+), the plugin doesn't uses the deprecated live() functions, instead it uses the new on() function to hook certain events.
- Revamped plugin configuration look and feel.

= 1.2.3.2 - 5 Jan 2012 =
- Fix minor compatibility issue with W3C Total Cache when the HTML output was minified.

= 1.2.3.1 - 13 Dec 2011 =
- Fix issue in users screen. When WangGuard is installed with s2member plugin, the columns added by the s2member plugin didn't display the value for each.

= 1.2.3 - 9 Dec 2011 =
- Minor tweak to the statistics

= 1.2.2 - 8 Dec 2011 =
- Compatibility with WordPress 3.3.
- Changelog outline displayed in the plugins page when there's an available update for WangGuard.
- Fix in wangguard-admin.php prompted by [boonebgorges](http://profiles.wordpress.org/users/boonebgorges) Thank you.
- Updated statistics charting components, now are correclty viewed on iPad, iPhone and iPod.
 
= 1.2.1 - 19 Sep 2011 =
* New gmail.com and googlemail.com duplicated account verifications. As gmail.com and googlemail.com ignore dots on the left side of the @ in an email address, Sploggers uses email variations to create multiple accounts using only one gmail.com account. Also, googlemail.com is an alias of gmail.com. WangGuard now checks for existing accounts having in count these rules in order to prevent fake accounts to be created. You can turn off this feature from the Configuration page.
* New optional DNS verification of the email domain (right side of the @ in an email address). New account's email domains are checked against your server's DNS for an associated MX record, if the resolution fails, a message is displayed to the user and the sign up process is stopped.

= 1.2.0.2 - 14 Sep 2011 =
* Adding 2 missing folders, Sorry.

= 1.2.0.1 - 14 Sep 2011 =
* NEW Added Italian Language, Thanks to Arturo.
* Minor bug fixing.

= 1.2.0 - 07 Sep 2011 =
* Added the ability to flag a user as "Not Splogger", overriding WangGuard response or cancelling a false/accidental report sent from your site.
* Reported users does not get deleted by default, this is a change of behavior from the previous version, if you want WangGuard to delete reported users, as on previous versions, go to Configuration and check the option "Delete users when reporting them to WangGuard".
* Added a new Statistics page which shows the last 30 days activity and a side by side comparison of the last 6 months activity (queries made to WangGuard / Sploggers blocked / Sploggers reported by you).
* Added a new dashboard box which shows the last 7 days activity.
* BuddyPress only, when clicking on "Load more" in the latest activity screen, report buttons now works as expected.
* BuddyPress only, you can now report users from the view post comments screen.
* Minor tweaks and bug fixing.

= 1.1.6 - 15 Aug 2011 =
* Fixed minor issues involving the URL for some links to the Configuration screen.

= 1.1.5 - 29 Jul 2011 =
* Fixed issue involving WangGuard questions on signup for WordPress 3.2.1 and its new 2 step registration when creating a blog on the registration screen.

= 1.1.4 - 23 Jun 2011 =
* Fixed compatibility issue for WordPress 3.2+.

= 1.1.3 - 18 May 2011 =
* Wizard now verifies, report and delete users in small groups in order to avoid timeouts.

= 1.1.2 - 12 May 2011 =
* Minor tweak on code.

= 1.1.1 - 11 May 2011 =
* Minor tweak on code.

= 1.1.0 - 10 May 2011 =
* NEW Wizard for detect and eliminate Sploggers
* NEW Mark as Splogger from post list
* NEW Add "Report blog and author" on every blog
* NEW Moderation Queue for repored users and blogs
* NEW Add report user on every Activity
* NEW Add report user on every profile

= 1.0.4 - 28 Mar 2011 =
* Minor tweaks to readme file.

= 1.0.3 - 23 Mar 2011 =
* Fixed a bug on the BuddyPress registration process which generated a log entry in apache's error log (duplicated entry on DB insert on table {DB_prefix}_wangguarduserstatus).

= 1.0.2 - 18 Mar 2011 =
* Disabling the main blog when reporting a user fixed, reported user's blogs gets flagged as spam now.
* Fixed a "Parser error" on servers which doesn't have "short_open_tag" enabled.

= 1.0.1 - 2 Mar 2011 =
* When reporting a user, user's blogs doesn't get flagged as spam because there is a risk of disabling the main blog. Working on a patch for the next release.

= 1.0.0 - 1 Mar 2011 =
* Initial Release

== What say people? ==



= What say users? =

[Shoutmeloud](http://www.shoutmeloud.com/wangguard-plugin-stop-wordpress-user-registration-spam.html) WangGuard Plugin : Stop WordPress User Registration Spam.

[Verasoul](http://www.verasoul.com/2011/12/como-mantener-wordpress-libre-de-sploggers.html) Como mantener wordpress libre de sploggers.

[Zaddick Blog:](http://zaddick.net/blog/best-spam-free-wordpress-buddypress-plugin/) WangGuard is the best plugin I have found to altogether eliminate spammers and sploggers from your WordPress and BuddyPress site.

[OrangeCopper Blog](http://orangecopper.com/blog/best-buddypress-plugins-download) Best BuddyPress Plugins download

[LOJ Tech](http://life.projektdeth.com/2011/07/07/spam-free-wordpress-blog/) Have a self hosted WordPress blog, and receiving an awful amount of spam? I’m not going to go over this like I usually do, I’ll just go over what it does and how great it can be to have on your WordPress Blog. The plugin is called WangGuard.

[PracticalWP](http://www.practicalwp.com/wangguard-protect-your-wordpress-site-against-sploggers/) If you are planning to start a membership site or open registrations on your blog, WangGuard can help you deal with sploggers more effectively.

[Kaliseo](http://www.agence-web-seo.com/2011/08/wangguard-lanti-splog/) Simple mais efficace. De quoi mettre des bâtons dans les roues aux développeurs de Link Farm Evolution et à 68 000 autres personnes.

[WordPressのセキュリティ関連のプラグイン28個](http://wp.tekapo.com/2011/08/24/wordpress-security-28-plugins/) マルチサイトなどでスプロガーやスパマーの登録を防ぐために外部のWangGuardウェブサービスでチェックする。

[AyudaWordpress](http://ayudawordpress.com/wangguard-el-anti-splog-definitivo/) Hace tiempo que José Conti viene luchando contra esa plaga de los blogs spam en instalaciones multisitio y BuddyPress, y parece que por fin ha dado con la solución.

[spammers کو - Sexeinträge (8 جوابات)](http://yesbo.de/es/groups/yesbo/forum/topic/spameintraege-sexeintraege/) اتفاق سے ، میں نے پلگ ان "WangGuard" سب کے لئے فعال سپیم زیادہ مؤثر انداز میں لڑنا ہے.

 [Blogurp](http://wordpress.org/support/topic/plugin-wangguard-works-perfect-with-wordpress-321-buddypress-15) Wang Guard works flawlessly on my website with WordPress 3.2.1 and BuddyPress 1.5. Thank You!!!!
 
[sarangan112](http://wordpress.org/support/topic/the-best-ever-plugin-to-protect-wpmu-sites-from-sploggers) Hello, I just would like to thank the author for this wonderful plugin which is the best ever plugin to protect WPMU sites from sploggers! And it works! :-) After have tried with spam math plugins, captcha etc. finally I found this plugins. :D You saved my life.

[Putoslocos](https://twitter.com/putoslokos/status/136756192205750272) @wangguard_es Es GENIAL. Ni un registro no real

= What say Sploggers or Unwanted User? =

From Twitter:

* Quelqu'un sait comment peut-on se protéger du ban par le service WangGuard? #LFE #splog #WPMU #antispam # antisplog
* #LFE does not work anymore. WangGuard… piece of shit!!!!!!.
* Please HELP!!!! WangGuard is deleting all my Backlinks!! #LFE
